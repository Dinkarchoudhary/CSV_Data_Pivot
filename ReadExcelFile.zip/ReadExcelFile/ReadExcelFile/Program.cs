﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.IO;
using System.Linq;

namespace ReadExcelFile
{
    class Program
    {
        static void Main(string[] args)
        {
            List<ExceData> excelData = new List<ExceData>();
            using (var reader = new StreamReader(@"D:\Downloads_Inube\SampleData.csv"))
            {
                int i = 0;
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if (i != 0)
                    {
                        ExceData obj = new ExceData();
                        obj.Transaction_Date = values[0];
                        obj.Product = values[1];
                        obj.Qty = Convert.ToInt32(values[2]);
                        obj.Unit_Price = Convert.ToInt32(values[3]);
                        obj.Client_Name = values[4];
                        excelData.Add(obj);
                    }
                    i++;
                }
            }

            var pivotList = excelData.GroupBy(cust => new { cust.Transaction_Date, cust.Product, cust.Qty, cust.Unit_Price, cust.Client_Name }).Select(x => new
            {
                Product = x.Key.Product,
                Client_Name = x.Key.Client_Name,
                Transaction_Date = x.Key
            });

            Console.WriteLine("Product\t\tClient\t\tTransaction_Date\tQty\tUnit_Price\n");
            foreach (var item in pivotList)
            {
                Console.WriteLine(item.Product + "\t" + item.Client_Name + "\t" + item.Transaction_Date.Transaction_Date + "\t\t" + item.Transaction_Date.Qty + "\t" + item.Transaction_Date.Unit_Price );
            }
        }
    }
    public class ExceData
    {
        public string Transaction_Date { get; set; }
        public string Product { get; set; }
        public int Qty { get; set; }
        public int Unit_Price { get; set; }
        public string Client_Name { get; set; }
    }
}
